# Render Backend — Quick Start (5 mins)

## 1) Create Service
- New **Web Service** → connect the `apps/api` folder (or upload it).
- **Build command:** `pip install -r requirements.txt`
- **Start command:** `uvicorn main:app --host 0.0.0.0 --port $PORT`
- Plan: Free is fine for now.

## 2) Environment
Set this env var in Render:
```
ALLOWED_ORIGIN=https://<your-netlify-site>.netlify.app
```
(If you use Netlify's proxy `/api/*`, CORS is already friendly.)

## 3) Test
Open:
- `GET /`        → `{"ok": true}`
- `GET /health`  → `{"status": "up"}`

## 4) Point Frontend to Backend
Your Netlify site's `netlify.toml` already proxies `/api/*` to Render:
```toml
[[redirects]]
from = "/api/*"
to = "https://<your-render-app>.onrender.com/:splat"
status = 200
force = true
```

Deploy frontend (drag `apps/frontend`) → click **Play Demo** to confirm audio works.
