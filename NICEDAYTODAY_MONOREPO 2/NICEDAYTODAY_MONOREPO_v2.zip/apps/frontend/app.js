document.getElementById('playBtn').addEventListener('click',()=>{
  const a=document.getElementById('demo');
  a.play().catch(e=>console.log('Playback blocked until user gesture:',e));
});